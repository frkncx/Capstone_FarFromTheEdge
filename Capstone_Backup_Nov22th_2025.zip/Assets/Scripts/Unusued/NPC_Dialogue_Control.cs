using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UIElements;

public class NPC_Dialogue_Control : MonoBehaviour
{
    public GameObject dialogueBox;
    
    public DialogueController firstDialogue;
    public DialogueController secondDialogue;
    public DialogueController finalDialogue;

    public bool isFirstDialogue;
    public bool isSecondDialogue;
    public bool isFinalDialogue;

    public bool isQuestComplete;
    public bool isDialogueStarted;


    [Header("Collision settings")] //This I got from my other dialogue videos

    public float dialogueRange;
    public LayerMask playerLayer;
    private Vector3 position;
    public bool playerHit = false;


    void Awake()
    {
        firstDialogue.enabled = false;
        secondDialogue.enabled = false;
        finalDialogue.enabled = false;

        isFirstDialogue = true;
        isSecondDialogue = false;
        isFinalDialogue = false;

        isDialogueStarted = false;
    }

    public void OnTriggerDialogue(InputAction.CallbackContext context)
    {
        // Press E
        if (Keyboard.current.eKey.wasPressedThisFrame && playerHit)
        {
            dialogueBox.SetActive(true);

            if (isFirstDialogue && !isSecondDialogue && !isFinalDialogue && !isDialogueStarted)
            {
                isDialogueStarted = true;
                firstDialogue.enabled = true;

                if (firstDialogue.isDialogueOver)
                {
                    isFirstDialogue = false;
                    isSecondDialogue = true;
                    isDialogueStarted = false;
                }
            }

            else if (!isFirstDialogue && isSecondDialogue && !isFinalDialogue && !isDialogueStarted)
            {
                isDialogueStarted = true;

                secondDialogue.enabled = true;
                if (isQuestComplete && secondDialogue.isDialogueOver)
                {
                    isSecondDialogue = false;
                    isFinalDialogue = true;
                    isDialogueStarted = true;

                }
            }

            else if (!isFirstDialogue && !isSecondDialogue && isFinalDialogue && !isDialogueStarted)
            {
                isDialogueStarted = true;

                finalDialogue.enabled = true;

            }

        }
    }

    public void QuestUnfinished() //Button to use that, must be added yet
    {
        isDialogueStarted = false;
        secondDialogue.enabled = false;
    }

    public void QuestFinished() //Button to use that, must be added yet
    {
        //Remove items
        isQuestComplete = true;
    }

    void FixedUpdate()
    {
        ShowDialogue(); //Check if player can start the interaction because it is near
    }

    void ShowDialogue() //A collider check without having a collider
    {
        position = transform.position;

        Collider[] hit = Physics.OverlapSphere(position, dialogueRange, playerLayer);

        if (hit.Length != 0)
        {
            playerHit = true;
            Debug.Log("Player can dialogue");
            Debug.Log(hit);

            //Make it popup the E to talk
        }

        else
        {
            playerHit = false;
        }
    }

    private void OnDrawGizmosSelected() //A visual reference for the collider
    {
        position = transform.position;

        Gizmos.DrawWireSphere(position, dialogueRange);
    }
}
