public interface IPlayerInteractable
{
    public void OnPlayerInteraction(Player player);
}
